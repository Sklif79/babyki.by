<?php
// Heading
$_['heading_title']    = 'Отчет по купонам';

// Text
$_['text_list']        = 'Купоны';

// Column
$_['column_name']      = 'Имя купона';
$_['column_code']      = 'Код';
$_['column_orders']    = 'Количество заказов';
$_['column_total']     = 'Итого';
$_['column_action']    = 'Действие';

// Entry
$_['entry_date_start'] = 'Дата начала';
$_['entry_date_end']   = 'Дата окончания';

